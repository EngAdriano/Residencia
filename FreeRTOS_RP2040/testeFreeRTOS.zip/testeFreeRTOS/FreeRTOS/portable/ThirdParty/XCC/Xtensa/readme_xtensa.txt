    FreeRTOS Port for Xtensa Configurable Processors
    ================================================

The Xtensa FreeRTOS port has moved and can be found in the 
"FreeRTOS-Kernel-Partner-Supported-Ports" submodule of FreeRTOS-Kernel:

FreeRTOS/Source/portable/ThirdParty/Partner-Supported-Ports/Cadence/Xtensa

Please see the Xtensa-specific README in this location for more details.

-End-
